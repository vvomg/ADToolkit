"""
PHASE 1.5: Deployment API Router

POST /api/deployment/start    — стартует развертывание, возвращает deployment_id
GET  /api/deployment/{id}     — статус + последние логи
GET  /api/deployment/         — список всех развертываний
"""

import asyncio
import logging
import uuid
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..core.config import settings
from ..models.schemas import ClusterDeploymentRequest, DeploymentStatus, DeploymentResponse
from ..models.db_models import DeploymentRun, DeploymentLog, get_db_engine, init_db
from ..models.license_models import ValidationResult
from ..core.validator import validator
from ..core.orchestrator import orchestrator

logger = logging.getLogger(__name__)

router = APIRouter()

# ─── Утилита: синхронная сессия (SQLite без async для Phase 1.5) ───

def _get_session() -> Session:
    engine = get_db_engine(settings.get_database_sync_url())
    init_db(engine)
    return Session(engine)


# ─────────────────────────────────────────────
# Request / Response schemas
# ─────────────────────────────────────────────

class DeploymentLogEntry(BaseModel):
    id: int
    created_at: datetime
    level: str
    phase: Optional[str]
    message: str
    server_ip: Optional[str]

    class Config:
        from_attributes = True


class DeploymentDetail(BaseModel):
    deployment_id: str
    status: str
    created_at: datetime
    updated_at: Optional[datetime]
    completed_at: Optional[datetime]
    error_message: Optional[str]
    logs: List[DeploymentLogEntry]

    class Config:
        from_attributes = True


class DeploymentListItem(BaseModel):
    deployment_id: str
    status: str
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True


# ─────────────────────────────────────────────
# Endpoints
# ─────────────────────────────────────────────

@router.post(
    "/start",
    summary="Запустить развертывание кластера",
    response_model=DeploymentResponse,
    status_code=202,
)
async def start_deployment(request: ClusterDeploymentRequest) -> DeploymentResponse:
    """
    Принимает полную конфигурацию (cluster + license),
    валидирует её и создаёт запись в БД.

    Оркестратор (Phase 4) будет запущен отдельно.
    Сейчас возвращает deployment_id для последующего polling.
    """
    # Валидация без SSH (быстрая, синхронная)
    validation: ValidationResult = await validator.validate_full_deployment(
        request, check_ssh=False
    )

    if not validation.valid:
        raise HTTPException(
            status_code=422,
            detail={
                "message": "Конфигурация не прошла валидацию",
                "errors": validation.errors,
                "warnings": validation.warnings,
            },
        )

    # Создаём запись в БД
    deployment_id = str(uuid.uuid4())
    session = _get_session()
    try:
        run = DeploymentRun(
            id=deployment_id,
            status=DeploymentStatus.CONFIGURATION.value,
            cluster_config=request.cluster_config.model_dump(mode="json", exclude={"package_config"}),
            license_config=request.license_config.model_dump(mode="json"),
            package_config=(
                pc.model_dump(mode="json")
                if (pc := request.resolved_package_config()) is not None
                else None
            ),
        )
        session.add(run)

        # Лог о старте
        log_entry = DeploymentLog(
            deployment_id=deployment_id,
            level="INFO",
            phase="configuration",
            message="Развертывание создано. Ожидание запуска оркестратора.",
        )
        session.add(log_entry)

        # Предупреждения из валидации → в логи
        for warning in validation.warnings:
            session.add(DeploymentLog(
                deployment_id=deployment_id,
                level="WARNING",
                phase="configuration",
                message=warning,
            ))

        session.commit()
        logger.info(f"Deployment создан: {deployment_id}")
    finally:
        session.close()

    # Запускаем оркестратор в фоне — HTTP возвращает deployment_id немедленно
    asyncio.create_task(orchestrator.run(deployment_id))
    logger.info(f"Оркестратор запущен фоново для {deployment_id}")

    return DeploymentResponse(
        deployment_id=deployment_id,
        status=DeploymentStatus.CONFIGURATION,
        message=(
            f"Развертывание запущено. ID: {deployment_id}. "
            f"Предупреждений: {len(validation.warnings)}. "
            f"Статус: GET /api/deployment/{deployment_id}"
        ),
    )


@router.get(
    "/",
    summary="Список всех развертываний",
    response_model=List[DeploymentListItem],
)
async def list_deployments() -> List[DeploymentListItem]:
    """Возвращает последние 50 развертываний, сортировка — новые первыми."""
    session = _get_session()
    try:
        runs = (
            session.query(DeploymentRun)
            .order_by(DeploymentRun.created_at.desc())
            .limit(50)
            .all()
        )
        return [
            DeploymentListItem(
                deployment_id=r.id,
                status=r.status,
                created_at=r.created_at,
                updated_at=r.updated_at,
            )
            for r in runs
        ]
    finally:
        session.close()


@router.get(
    "/{deployment_id}",
    summary="Статус и логи развертывания",
    response_model=DeploymentDetail,
)
async def get_deployment(deployment_id: str) -> DeploymentDetail:
    """Возвращает текущий статус + последние 100 записей лога."""
    session = _get_session()
    try:
        run: Optional[DeploymentRun] = session.get(DeploymentRun, deployment_id)
        if not run:
            raise HTTPException(status_code=404, detail=f"Deployment {deployment_id} не найден")

        logs = (
            session.query(DeploymentLog)
            .filter(DeploymentLog.deployment_id == deployment_id)
            .order_by(DeploymentLog.created_at.desc())
            .limit(100)
            .all()
        )

        return DeploymentDetail(
            deployment_id=run.id,
            status=run.status,
            created_at=run.created_at,
            updated_at=run.updated_at,
            completed_at=run.completed_at,
            error_message=run.error_message,
            logs=[
                DeploymentLogEntry(
                    id=l.id,
                    created_at=l.created_at,
                    level=l.level,
                    phase=l.phase,
                    message=l.message,
                    server_ip=l.server_ip,
                )
                for l in logs
            ],
        )
    finally:
        session.close()


@router.get(
    "/{deployment_id}/report",
    summary="HTML-отчёт о развертывании",
    response_class=HTMLResponse,
)
async def get_deployment_report(deployment_id: str) -> HTMLResponse:
    """Возвращает HTML-отчёт, сгенерированный после завершения развертывания."""
    session = _get_session()
    try:
        run = session.get(DeploymentRun, deployment_id)
        if not run:
            raise HTTPException(status_code=404, detail=f"Deployment {deployment_id} не найден")
        if not run.report_html:
            raise HTTPException(
                status_code=404,
                detail=(
                    f"Отчёт для deployment {deployment_id} ещё не сгенерирован. "
                    f"Текущий статус: {run.status}"
                )
            )
        return HTMLResponse(content=run.report_html)
    finally:
        session.close()
