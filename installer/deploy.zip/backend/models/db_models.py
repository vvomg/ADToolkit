"""
PHASE 0.3: SQLAlchemy Database Models

Модели для хранения в SQLite информации о развертываниях и лицензиях.
"""

from pathlib import Path

from sqlalchemy import (
    Column,
    String,
    Integer,
    DateTime,
    Text,
    Boolean,
    JSON,
    ForeignKey,
    Enum as SAEnum,
    inspect,
    text,
)
from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy import create_engine
from sqlalchemy.engine.url import make_url
from datetime import datetime
import uuid

Base = declarative_base()


def _gen_uuid() -> str:
    return str(uuid.uuid4())


class DeploymentRun(Base):
    """
    Основная запись о запуске развертывания.
    """
    __tablename__ = "deployment_runs"

    id = Column(String(36), primary_key=True, default=_gen_uuid)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = Column(String(50), nullable=False, default="configuration")
    cluster_config = Column(JSON, nullable=True)   # ClusterInput as JSON
    license_config = Column(JSON, nullable=True)   # LicenseRequestParams as JSON
    package_config = Column(JSON, nullable=True)   # PackageConfig as JSON
    error_message = Column(Text, nullable=True)
    report_html = Column(Text, nullable=True)
    completed_at = Column(DateTime, nullable=True)

    # Relationships
    logs = relationship("DeploymentLog", back_populates="deployment", cascade="all, delete-orphan")
    health_checks = relationship("HealthCheckResult", back_populates="deployment", cascade="all, delete-orphan")
    license_requests = relationship("LicenseRequest", back_populates="deployment", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<DeploymentRun id={self.id} status={self.status}>"


class DeploymentLog(Base):
    """
    Лог отдельного события в процессе развертывания.
    """
    __tablename__ = "deployment_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    deployment_id = Column(String(36), ForeignKey("deployment_runs.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    level = Column(String(10), default="INFO")  # DEBUG, INFO, WARNING, ERROR
    phase = Column(String(50), nullable=True)
    message = Column(Text, nullable=False)
    server_ip = Column(String(45), nullable=True)
    command = Column(Text, nullable=True)
    output = Column(Text, nullable=True)

    # Relationship
    deployment = relationship("DeploymentRun", back_populates="logs")

    def __repr__(self) -> str:
        return f"<DeploymentLog id={self.id} level={self.level} phase={self.phase}>"


class HealthCheckResult(Base):
    """
    Результат проверки здоровья узла кластера.
    """
    __tablename__ = "health_check_results"

    id = Column(Integer, primary_key=True, autoincrement=True)
    deployment_id = Column(String(36), ForeignKey("deployment_runs.id"), nullable=False)
    checked_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    server_ip = Column(String(45), nullable=False)
    server_hostname = Column(String(255), nullable=True)
    check_type = Column(String(50), nullable=False)  # ivamail, postgresql, nfs, ssh
    success = Column(Boolean, nullable=False, default=False)
    details = Column(JSON, nullable=True)
    error_message = Column(Text, nullable=True)

    # Relationship
    deployment = relationship("DeploymentRun", back_populates="health_checks")

    def __repr__(self) -> str:
        return f"<HealthCheckResult server={self.server_ip} type={self.check_type} ok={self.success}>"


class LicenseRequest(Base):
    """
    Запись о запросе лицензии (CMD-протокол).
    """
    __tablename__ = "license_requests"

    id = Column(Integer, primary_key=True, autoincrement=True)
    deployment_id = Column(String(36), ForeignKey("deployment_runs.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    server_ip = Column(String(45), nullable=False)
    request_data = Column(JSON, nullable=True)    # Raw CMD response
    license_file_path = Column(String(500), nullable=True)
    installed = Column(Boolean, default=False)
    installed_at = Column(DateTime, nullable=True)
    error_message = Column(Text, nullable=True)

    # Relationship
    deployment = relationship("DeploymentRun", back_populates="license_requests")

    def __repr__(self) -> str:
        return f"<LicenseRequest id={self.id} server={self.server_ip} installed={self.installed}>"


def _normalize_sync_sqlite_url(database_url: str) -> str:
    """Полный sync-URL для create_engine (без sqlite+aiosqlite)."""
    u = database_url.strip()
    if "://" not in u:
        return f"sqlite:///{u}"
    if u.startswith("sqlite+aiosqlite:"):
        return "sqlite:" + u[len("sqlite+aiosqlite:") :]
    return u


def _ensure_sqlite_parent_dir(database_url: str) -> None:
    """Создать родительскую директорию для файла SQLite, если нужно."""
    url = make_url(database_url)
    if url.drivername != "sqlite":
        return
    dbname = url.database
    if not dbname or dbname == ":memory:" or dbname.startswith("file::memory"):
        return
    path = Path(dbname)
    if not path.is_absolute():
        path = Path.cwd() / path
    path.parent.mkdir(parents=True, exist_ok=True)


_engine_cache: dict = {}


def get_db_engine(database_url: str = "sqlite:///./ivamail_deploy.db"):
    """Синхронный движок SQLAlchemy — singleton per URL."""
    sync_url = _normalize_sync_sqlite_url(database_url)
    if sync_url in _engine_cache:
        return _engine_cache[sync_url]
    _ensure_sqlite_parent_dir(sync_url)
    engine = create_engine(
        sync_url,
        connect_args={"check_same_thread": False},
        echo=False,
    )
    _engine_cache[sync_url] = engine
    return engine


def _upgrade_sqlite_schema(engine) -> None:
    """
    Добавить в SQLite недостающие столбцы.
    create_all() не меняет уже существующие таблицы — после смены моделей нужен ADD COLUMN.
    """
    if engine.dialect.name != "sqlite":
        return

    inspector = inspect(engine)
    with engine.begin() as conn:
        for table in Base.metadata.sorted_tables:
            if not inspector.has_table(table.name):
                continue
            existing = {c["name"] for c in inspector.get_columns(table.name)}
            for column in table.columns:
                if column.name in existing:
                    continue
                if column.primary_key:
                    continue
                if not column.nullable and column.server_default is None:
                    # SQLite: ADD COLUMN NOT NULL без DEFAULT несовместим со старыми строками
                    continue
                coltype = column.type.compile(dialect=engine.dialect)
                ddl = f'ALTER TABLE "{table.name}" ADD COLUMN "{column.name}" {coltype}'
                conn.execute(text(ddl))
                existing.add(column.name)


def init_db(engine):
    """Инициализировать БД — создать все таблицы и подтянуть схему SQLite."""
    Base.metadata.create_all(bind=engine)
    _upgrade_sqlite_schema(engine)
